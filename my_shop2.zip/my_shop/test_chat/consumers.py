import json

from asgiref.sync import sync_to_async
from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import MessageDB

class ChatConsumer(AsyncWebsocketConsumer):

    async def connect(self):
        self.GroupName = self.scope['url_route']['kwargs']['room_name']
        print(self.GroupName)
        self.roomGroupName = f"chat_{self.GroupName}"
        await self.channel_layer.group_add(
            self.roomGroupName,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel.name.group_discard(
            self.roomGroupName,
            self.channel_name
        )

    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message = text_data_json["message"]
        username = text_data_json["username"]

        # Используем await для ожидания выполнения синхронной функции
        await sync_to_async(MessageDB.objects.create)(
            name_room=self.GroupName,
            message=message,
            user=username
        )

        await self.channel_layer.group_send(
            self.roomGroupName, {
                "type": "sendMessage",
                "message": message,
                "username": username,
            })

    async def sendMessage(self, event):
        message = event["message"]
        username = event["username"]
        await self.send(text_data=json.dumps({"message": message, "username": username}))

class OnlineConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_group_name = 'online_users'

        # Присоединение к группе
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

        # Увеличение счетчика онлайн пользователей
        await self.update_online_count()

    async def disconnect(self, close_code):
        # Удаление из группы
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

        # Уменьшение счетчика онлайн пользователей
        await self.update_online_count()

    async def receive(self, text_data):
        pass

    async def update_online_count(self):
        # Получение количества подключенных пользователей
        count = await self.get_online_count()

        # Отправка обновленного количества в группу
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'online_count',
                'count': count
            }
        )

    async def online_count(self, event):
        count = event['count']

        # Отправка количества на клиент
        await self.send(text_data=json.dumps({
            'count': count
        }))

    @database_sync_to_async
    def get_online_count(self):
        return len(self.channel_layer.groups.get(self.room_group_name))