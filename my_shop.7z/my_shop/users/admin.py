from django.contrib import admin
from .models import Users,EmailVerification
# Register your models here.

admin.site.register(Users)

@admin.register(EmailVerification)
class EmailVerificationAdmin(admin.ModelAdmin):
    list_display = ('code','user','expiration')
    fields = ('code','user','expiration','created')
    readonly_fields = ('created',)