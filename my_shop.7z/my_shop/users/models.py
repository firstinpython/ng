from django.core.mail import send_mail
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.urls import reverse
from django.conf import settings
from django.utils.timezone import now


# Create your models here.

class Users(AbstractUser):
    avatar = models.FileField(verbose_name="avatar", upload_to="avatar")
    email = models.EmailField(unique=True, blank=False)
    is_verification_email = models.BooleanField(default=False)

    # age = models.PositiveIntegerField(verbose_name="age")

    def __str__(self):
        return f"{self.username}"


class FeedBackModel(models.Model):
    name = models.CharField(verbose_name="Пользователь", max_length=120)
    description = models.TextField(verbose_name="Текст")
    email = models.EmailField(verbose_name="Почта пользователя")

    def __str__(self):
        return f"{self.name} | {self.email}"


class EmailVerification(models.Model):
    code = models.UUIDField(unique=True)
    user = models.ForeignKey(to=Users, on_delete=models.CASCADE)
    created = models.DateTimeField(auto_now_add=True)
    expiration = models.DateTimeField()

    def __str__(self):
        return f"{self.user.email}"

    def send_verification_email(self):
        link = reverse('users:email_verification', kwargs={'email': self.user.email, 'code': self.code})
        verification_link = f'{settings.DOMAIN_NAME}{link}'
        subject = f'Подтверждение учетной записи для {self.user.username}'
        message = f'Для подтверждения учетной записи для {self.user.email} перейдите по ссылке: {verification_link}'
        send_mail(
            subject=subject,
            message=message,
            from_email=settings.EMAIL_HOST_USER,
            recipient_list=[self.user.email]
        )

    def is_expired(self):
        return True if now() >= self.expiration else False
