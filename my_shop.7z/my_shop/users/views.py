from django.contrib.auth.mixins import UserPassesTestMixin, LoginRequiredMixin
from django.contrib.auth.views import LoginView, PasswordResetView
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.contrib import auth
from django.urls import reverse_lazy
from django.views.generic import UpdateView, TemplateView
from django.views.generic.edit import CreateView
from django.contrib.auth.decorators import login_required



from .forms import SignIn_User, SignUp_User,Profile,FeedBackForm, ResetForm
from .models import Users, FeedBackModel, EmailVerification
# Create your views here.


class LoginUser(LoginView):
    form_class = SignIn_User
    template_name = 'users/sign_in.html'

    def get_success_url(self):
        return reverse_lazy('product:product')

class UserRegistrationView(CreateView):
    model = Users
    template_name = 'users/sign_up.html'
    form_class = SignUp_User
    success_url = reverse_lazy('product:product')



class UserProfileView(UpdateView):
    model = Users
    form_class = SignUp_User
    template_name = 'users/profile.html'

    def get_success_url(self):
        return reverse_lazy('users:profile',args=(self.object.id,))


class FeedBack(CreateView):
    model = FeedBackModel
    template_name = "users/feedbackform.html"
    form_class = FeedBackForm

    def get_success_url(self):
        return reverse_lazy('product:product')

class EmailVerificationView(TemplateView):
    template_name = 'users/veremail.html'

    def get(self, request, *args, **kwargs):
        code = kwargs['code']
        user = Users.objects.get(email=kwargs["email"])
        email_verification = EmailVerification.objects.filter(user=user, code=code)
        print(email_verification)
        if email_verification.exists() and not email_verification.first().is_expired():
            user.is_verification_email = True
            user.save()
            email_verification.first().delete()
            return super(EmailVerificationView, self).get(request, *args, **kwargs)
        else:
            return HttpResponse('no')

class PassResetView(PasswordResetView):
    template_name = 'users/password_reset_form.html'
    # form_class = ResetForm

