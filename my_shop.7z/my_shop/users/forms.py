import uuid
from datetime import timedelta
from django.utils.timezone import now
from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm, UserChangeForm
from .models import Users, FeedBackModel, EmailVerification


class SignIn_User(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(
        attrs={
            'class':"form-control",
            'id':"floatingInput",
            'placeholder':"name@example.com"
        }
    ))
    password = forms.CharField(widget=forms.PasswordInput(
        attrs={
            'class':"form-control",
            'id':"floatingPassword",
            "placeholder":"Пароль"
        }
    ))
    class Meta:
        model = Users
        fields = ("username", "password")


class SignUp_User(UserCreationForm):
    class Meta:
        model = Users
        fields = ("username", "first_name", "last_name", "email", "password1", "password2")

    def save(self, commit=True):
        user = super(SignUp_User,self).save(commit=True)
        expiration = now() + timedelta(hours=24)
        record = EmailVerification.objects.create(code=uuid.uuid4(),user=user, expiration=expiration)
        record.send_verification_email()
        return user



class Profile(UserChangeForm):
    class Meta:
        model = Users
        fields = ("username", "first_name", "last_name",  "email")

class FeedBackForm(forms.ModelForm):
    class Meta:
        model = FeedBackModel
        fields = "__all__"


class ResetForm(forms.Form):
    email = forms.CharField(widget=forms.EmailInput())
