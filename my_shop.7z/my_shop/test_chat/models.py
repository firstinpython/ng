from django.db import models

# Create your models here.
class MessageDB(models.Model):
    name_room = models.CharField(verbose_name="name_room", max_length=120)
    message = models.CharField(verbose_name='message', max_length=120)
    user = models.CharField(verbose_name="username", max_length=120)