from django.core.paginator import Paginator
from django.urls import reverse_lazy
from django.shortcuts import redirect,render
from .models import Product, Basket, Category
from django.views import generic
from .filters import ProductFilter
from .forms import ProductCreateForm
from django.contrib.auth.mixins import UserPassesTestMixin
from django.http import HttpResponseRedirect

# Create your views here.

class ProductListView(generic.ListView):
    model = Product
    template_name = "products/catalog.html"
    context_object_name = 'products'
    paginate_by = 2

    def get_queryset(self):
        queryset = super().get_queryset()
        self.filterset = ProductFilter(self.request.GET, queryset=queryset)
        return self.filterset.qs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filter'] = self.filterset
        context['catalogs'] = Category.objects.all()
        return context


class CreateProductView(UserPassesTestMixin,generic.edit.FormView):
    model = Product
    template_name = 'products/create.html'
    form_class = ProductCreateForm
    success_url = reverse_lazy('product:product')
    def form_valid(self, form):
        form.save()
        return super().form_valid(form)
    def test_func(self):
        return self.request.user.is_superuser

    def handle_no_permission(self):
        return redirect('product:product')  #    def test_func(self):






class UpdateProductView(UserPassesTestMixin,generic.UpdateView):
    model = Product
    fields = [
        "name",
        "description",
        "price",
        "quantity",
        "is_published",
        "category",
        "delivery_time",
        "brand"
    ]
    success_url = reverse_lazy('product:product')
    template_name = "products/update.html"

    def test_func(self):
        return self.request.user.is_superuser

    def handle_no_permission(self):
        return redirect('product:product')  #

class DeleteProductView(UserPassesTestMixin,generic.DeleteView):
    model = Product
    success_url = reverse_lazy('product:product')
    template_name = "products/delete.html"

    def test_func(self):
        return self.request.user.is_superuser

    def handle_no_permission(self):
        return redirect('product:product')  #

class Catalog(generic.TemplateView):
    template_name = "products/catalog.html"




def basket_add(request, product_id):
    product = Product.objects.get(pk=product_id)
    baskets = Basket.objects.filter(user=request.user, product=product)

    if not baskets.exists():
        Basket.objects.create(user=request.user, product=product,quantity=1)

    else:
        basket = baskets.first()
        basket.quantity+=1
        basket.save()


    return HttpResponseRedirect(request.META['HTTP_REFERER'])

def basket(request):
    basket_products = Basket.objects.filter(user=request.user)

    context = {
        'products':basket_products
    }

    return render(request,'products/basket.html',context=context)