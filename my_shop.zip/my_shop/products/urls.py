from django.urls import path
from .views import  ProductListView,CreateProductView, UpdateProductView, DeleteProductView,Catalog, basket_add, basket

app_name = "product"
urlpatterns = [
    path("",ProductListView.as_view(),name="product"),
    path('create_product', CreateProductView.as_view()),
    path('update/<pk>', UpdateProductView.as_view()),
    path('delete/<pk>',DeleteProductView.as_view()),
    path('catalog', Catalog.as_view()),
    path('basket_add/<int:product_id>/',basket_add, name="basket_add"),
    path('basket',basket,name="basket")

]