import django_filters
from django import forms

from .models import Product, Brand
from .widgets import CustomOrderingWidget

class ProductFilter(django_filters.FilterSet):
    price_min = django_filters.NumberFilter(field_name="price", lookup_expr='gte')
    price_max = django_filters.NumberFilter(field_name="price", lookup_expr='lte')
    price_order = django_filters.OrderingFilter(
        fields=(
            ('price', 'price'),
        ),
        widget=CustomOrderingWidget,
        label='Order'
    )
    brand__name = django_filters.ModelChoiceFilter(
        queryset=Brand.objects.all(),
        widget = forms.Select(
            attrs={
                'class':'dropdown btn btn-secondary dropdown-toggle'
            }
        )
    )
    class Meta:
        model = Product
        fields = ['price_min', 'price_max', 'price_order',"brand__name"]