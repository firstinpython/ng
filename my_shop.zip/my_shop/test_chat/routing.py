from django.urls import path , include
from .consumers import ChatConsumer,OnlineConsumer

# Here, "" is routing to the URL ChatConsumer which
# will handle the chat functionality.
websocket_urlpatterns = [
    path("ws/<str:room_name>" , ChatConsumer.as_asgi()) ,
    path("ws", OnlineConsumer.as_asgi())
]